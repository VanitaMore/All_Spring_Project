package com.batchDataService.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "BATCH_DETAILS")
public class BatchDetails {

	@Id
	@GeneratedValue
	@Column(name = "CHUNK_ID")
	private String chunkId;

	private Date scheduledDate;

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "batchDetails",cascade = {CascadeType.MERGE,CascadeType.REFRESH,CascadeType.DETACH})
	private List<DeviceDetails> deviceDetails;

	public List<DeviceDetails> getDeviceDetails() {
		return deviceDetails;
	}

	public void setDeviceDetails(List<DeviceDetails> deviceDetails) {
		this.deviceDetails = deviceDetails;
	}

	public String getChunkId() {
		return chunkId;
	}

	public void setChunkId(String chunkId) {
		this.chunkId = chunkId;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

//	@Override
//	public String toString() {
//		return "BatchDetails [chunkId=" + chunkId + ", scheduledDate=" + scheduledDate + ", deviceDetails="
//				+ deviceDetails + "]";
//	}

}
