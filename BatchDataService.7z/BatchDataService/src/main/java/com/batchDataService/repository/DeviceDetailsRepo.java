package com.batchDataService.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.batchDataService.entity.DeviceDetails;



@Repository
public interface DeviceDetailsRepo extends CrudRepository<DeviceDetails	, String> {

}