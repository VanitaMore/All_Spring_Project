package com.batchDataService.repository.serviceImp;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.batchDataService.entity.BatchDetails;
import com.batchDataService.entity.DeviceDetails;
import com.batchDataService.repository.BatchDetailsRepo;
import com.batchDataService.repository.DeviceDetailsRepo;
import com.batchDataService.repository.service.BatchDataService;

@Service
public class BatchDataServiceImp implements BatchDataService {
	
	@Autowired BatchDetailsRepo batchDetailsRepo;
	
	@Autowired DeviceDetailsRepo deviceDetailsRepo; 



	@SuppressWarnings("unchecked")
	@Override
	public List<DeviceDetails> fetchDeviceListByChunkId(String chunkId) {
		// TODO Auto-generated method stub
		//Optional<BatchDetails> findById = batchDetailsRepo.findById(chunkId);
		BatchDetails findById = batchDetailsRepo.findOne(chunkId);
		List<DeviceDetails> list=findById.getDeviceDetails();
		return list ;
	}

	@Override
	public void updateByChunkId(String chunkId) {
		//List<DeviceDetails> list= new CopyOnWriteArrayList<DeviceDetails>();
		
		BatchDetails findById = batchDetailsRepo.findOne(chunkId);

		List<DeviceDetails> list=findById.getDeviceDetails();
		 System.out.println(list);
		 List<DeviceDetails>saveDeviceDetails=new ArrayList<DeviceDetails>();
		for (DeviceDetails deviceDetails : list) {
			System.out.println(deviceDetails.getDeviceId());
			deviceDetails.setDeviceId(deviceDetails.getDeviceId());
			deviceDetails.setBatchDetails(findById);
			deviceDetails.setStatusOfUpgrade(true);
			saveDeviceDetails.add(deviceDetails);
		}
		
		deviceDetailsRepo.save(saveDeviceDetails);
		
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<BatchDetails> fetchBatchChunk() {
		// TODO Auto-generated method stub
		return (List<BatchDetails>) batchDetailsRepo.findAll();
	}

	@Override
	public void updateByDeviceId(String deviceId) {
		// TODO Auto-generated method stub
		
		DeviceDetails details= deviceDetailsRepo.findOne(deviceId);
		details.setStatusOfUpgrade(true);
		deviceDetailsRepo.save(details);
		
	}

}
