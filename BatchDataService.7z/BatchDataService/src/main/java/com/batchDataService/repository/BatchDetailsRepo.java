package com.batchDataService.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.batchDataService.entity.BatchDetails;



@Repository
public interface BatchDetailsRepo extends CrudRepository<BatchDetails, String> {

}
