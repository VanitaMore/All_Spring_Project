package com.batchDataService.repository.service;

import java.util.List;
import java.util.Optional;

import com.batchDataService.entity.BatchDetails;
import com.batchDataService.entity.DeviceDetails;

public interface BatchDataService {
	List<BatchDetails>  fetchBatchChunk();

	List<DeviceDetails> fetchDeviceListByChunkId(String chunkId);

	void updateByChunkId(String chunkId);

	void updateByDeviceId(String deviceId);
}
