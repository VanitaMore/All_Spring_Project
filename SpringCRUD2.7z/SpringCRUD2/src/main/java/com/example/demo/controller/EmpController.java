package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Emp;
import com.example.demo.service.EmpService;

@RestController
@RequestMapping(value="/employee")
public class EmpController {
	
	@Autowired EmpService service;
	
	@GetMapping(value="/getEmployee")
	public List<Emp> findAllEmployees(){
		List<Emp> list= service.findAll();
		return list;
	} 
	
	
	/*
	 * @GetMapping(value="/getEmployee") public ResponseEntity<List<Emp>> findAll()
	 * { return ResponseEntity.ok(service.findAll()); }
	 */
	 
	
	
	@PostMapping(value="/insertEmployee")
	public Emp insertEmp(@RequestBody Emp emp) {
		return service.insertEmp(emp);
		
	}
	
	
	/*
	 * @GetMapping(value="/getEmployeeById/{id}") public ResponseEntity<Emp>
	 * getEmployeeById(@PathVariable(value="id") int id){ Emp
	 * list=service.getEmployeeById(id); return new ResponseEntity<Emp>
	 * (list,HttpStatus.OK);
	 * 
	 * }
	 */
	 
	
	@GetMapping(value="/getEmployeeById/{id}")
	public Emp getEmployeeById(@PathVariable(value="id") int id){
		return service.getEmployeeById(id);
		 
		
	}
	
	
	/*
	 * @PutMapping(value="/update") public ResponseEntity<Emp>
	 * updateEmployeeById(@RequestBody Emp emp){ Emp
	 * listUpdate=service.getEmployeeById(emp.getEmpId());
	 * service.updateEmployee(emp,emp.getEmpId()); return new ResponseEntity<Emp>
	 * (listUpdate,HttpStatus.OK); }
	 */
	 
	
	 @PutMapping(value="/updateEmployee/{empId}")
		public Emp updateEmployeeById(@PathVariable(value="empId") int empId ,@RequestBody  Emp empBody){
			return service.updateEmployee(empId,empBody);
			
		}
	 
	 @DeleteMapping(value="/deleteById/{deleteId}")
	 public void deleteEmployeeById(@PathVariable(value="deleteId") int  deleteId) {
		 service.deleteEmployeeById(deleteId);
	 }

}
