package com.example.demo.service;

import java.util.List;


import com.example.demo.model.Emp;

public interface EmpService {

	List<Emp> findAll();

	Emp insertEmp(Emp emp);

	Emp getEmployeeById(int id);

	Emp updateEmployee(int empId, Emp empBody);

	void deleteEmployeeById(int deleteId);

	

}
