package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.model.Emp;

import com.example.demo.repository.EmpRepository;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired EmpRepository repo;
	
	@Override
	public List<Emp> findAll() {
		List<Emp> list=(List<Emp>) repo.findAll();
		System.out.println("data is"+list);
		return list;
	}
	@Override
	public Emp insertEmp(Emp emp) {
		return repo.save(emp);
	}
	
	@Override
	public Emp getEmployeeById(int id) {
		return repo.findOne(id)  ;
		
	}
	@Override
	public Emp updateEmployee(int empId, Emp empBody) {
    Emp findEmployeeById=repo.findOne(empId);
    findEmployeeById.setEmpAddr(empBody.getEmpAddr());
    findEmployeeById.setEmpCity(empBody.getEmpCity());
    Emp saveAndUpdateData=repo.save(findEmployeeById);
	return saveAndUpdateData;
    
	}
	
	/*
	 * Emp getEmpId=repo.findOne(empId); getEmpId.setEmpAddr(empBody.getEmpAddr());
	 * getEmpId.setEmpCity(empBody.getEmpCity()); Emp
	 * saveUpdatedData=repo.save(getEmpId); return saveUpdatedData;
	 */
	
	@Override
	public void deleteEmployeeById(int deleteId) {
		repo.delete(deleteId);
	}
	

	
	

}
