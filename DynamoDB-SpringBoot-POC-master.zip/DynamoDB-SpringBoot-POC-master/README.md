# Spring Boot Amazon DynamoDB POC
This is a simple Spring Boot CommandLineRunner application to illustrate how we can use the AWS Java SDK to write objects to DynamoDB and read objects from the DB.